请将以下资源文件放到与index.html同一目录：
1. beauty.jpg - 你的美女图片文件
2. ribenluo.mp3 - 蔡依林《日不落》音乐文件

打开index.html即可体验小游戏。
